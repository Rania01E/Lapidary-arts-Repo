
import React from 'react';

const TermsOfService = () => {
  return (
    <div className="bg-white text-gray-800 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold text-center mb-8">Terms of Service</h1>

        <div className="space-y-6 text-sm">
          <p><strong>Effective Date:</strong> February 15, 2026</p>

          <p>
            Please read these Terms of Service ("Terms", "Terms of Service") carefully before using the Lapidary Arts Jewelry website (the "Service") operated by Lapidary Arts Jewelry ("us", "we", or "our").
          </p>
          <p>
            Your access to and use of the Service is conditioned on your acceptance of and compliance with these Terms. These Terms apply to all visitors, users, and others who access or use the Service.
          </p>
          <p>
            By accessing or using the Service you agree to be bound by these Terms. If you disagree with any part of the terms then you may not access the Service.
          </p>

          <h2 className="text-xl font-semibold pt-4">1. ACCOUNTS</h2>
          <p>
            When you create an account with us, you must provide us information that is accurate, complete, and current at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination of your account on our Service.
          </p>
          <p>
            You are responsible for safeguarding the password that you use to access the Service and for any activities or actions under your password, whether your password is with our Service or a third-party service.
          </p>

          <h2 className="text-xl font-semibold pt-4">2. INTELLECTUAL PROPERTY</h2>
          <p>
            The Service and its original content, features, and functionality are and will remain the exclusive property of Lapidary Arts Jewelry and its licensors. The Service is protected by copyright, trademark, and other laws of both the United States and foreign countries.
          </p>

          <h2 className="text-xl font-semibold pt-4">3. LINKS TO OTHER WEB SITES</h2>
          <p>
            Our Service may contain links to third-party web sites or services that are not owned or controlled by Lapidary Arts Jewelry.
          </p>
          <p>
            Lapidary Arts Jewelry has no control over, and assumes no responsibility for, the content, privacy policies, or practices of any third-party web sites or services. You further acknowledge and agree that Lapidary Arts Jewelry shall not be responsible or liable, directly or indirectly, for any damage or loss caused or alleged to be caused by or in connection with use of or reliance on any such content, goods or services available on or through any such web sites or services.
          </p>

          <h2 className="text-xl font-semibold pt-4">4. GOVERNING LAW</h2>
          <p>
            These Terms shall be governed and construed in accordance with the laws of the State of Texas, United States, without regard to its conflict of law provisions.
          </p>

          <h2 className="text-xl font-semibold pt-4">5. CHANGES</h2>
          <p>
            We reserve the right, at our sole discretion, to modify or replace these Terms at any time. If a revision is material we will try to provide at least 30 days' notice prior to any new terms taking effect. What constitutes a material change will be determined at our sole discretion.
          </p>

          <h2 className="text-xl font-semibold pt-4">6. CONTACT US</h2>
          <p>
            If you have any questions about these Terms, please contact us:
          </p>
          <p>
            Lapidary Arts Jewelry<br />
            3400 Preston Rd #250<br />
            Plano, TX 75093<br />
            <a href="mailto:lauren@lapidaryartsjewelry.com">lauren@lapidaryartsjewelry.com</a><br />
            <a href="tel:9729641090">(972) 964-1090</a>
          </p>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;
